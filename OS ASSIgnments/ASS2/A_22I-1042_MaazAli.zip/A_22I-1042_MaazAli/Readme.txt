//Maaz Ali
//CS A
//22i-1042
//IMP README
In Q1 there is a specific issue
while running on my laptop sometimes it will give error for large number of players
"sh: error while loading shared libraries: libc.so.6: cannot open shared object file: Error 24"
I checked this error online and it staes that "The system is unable to load the libc.so.6 shared library, which is a critical system library for Linux-based systems."
All the solutions to this error suggest that I go and delete some files from system folders or reboot the system or the disk may be corrupted. 
This is very risky as it can delete my source code files or even ubuntu.
Most of the times it works fine but other times it gives issues.

For Q2 first compile Client.cpp in exe file 'Client' because it is the same name i have used in Server.cpp to exec
I havent included exe file in folder because it was giving errors while uploading. 
