
#include<stdio.h>
int main()
{
printf("hello world from master script\n");
return 0;
}
