1. Docker wont let me ake user name 22i-1042(because of sepecial character) and 22i1042 for some other reason so usr name is (i221042).
It also wont let me take capital chars in repo name.



(important)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
otherwise it will run infinite loop and give problems


commands to run:
sudo docker pull i221042/assignment_01_asction_a_sp2024_os:latest
sudo docker run --rm -it assignment_01_asction_a_sp2024_os:1
